package com.library.database;

import java.sql.Statement;

public interface DatabaseConnection {
	
	Statement doConnection();

}
